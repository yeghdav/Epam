#!/bin/bash

# create a new file to store the updated accounts
touch ./accounts_new.csv

# read the input file line by line and split the fields using comma as the delimiter
while IFS="," read -r id location_id name title email department;
do
        # check if email field is missing @ symbol and email field is not empty
        email_contains_at=$(echo $email | grep "@")
        if [[ -z "$email_contains_at" ]] && [[ -n $email ]];
        then
                # append email value to the end of title field
                title=$title","$email
        fi

        # extract first name from the name field
        first_name=$(echo $name | cut -d " " -f 1)

        # convert first name to lowercase
        first_name_lowercase=${first_name,,}

        # extract last name from the name field
        last_name=$(echo $name | cut -d " " -f 2)

        # convert last name to lowercase
        last_name_lowercase=${last_name,,}

        # combine first and last names with the first letter of each name capitalized
        name_surname="${first_name_lowercase^} ${last_name_lowercase^}"

        # create an email address using the first letter of the first name, last name, location id and the domain "@abc.com"
        email_first_letter=$(echo $first_name_lowercase | cut -c 1)
        email_suffix="@abc.com"
        if [[ $(grep -c -i "$email_first_letter$last_name" ./accounts_new.csv) -ne 0 ]]; then
                email_suffix="${location_id}${email_suffix}"
        fi
        email="${email_first_letter}${last_name_lowercase}${email_suffix}"

        # convert email address to lowercase
        email=${email,,}

        # check if the name already exists in the input file
        name_exists=$(cat ./accounts.csv | grep -iF  "$name" | wc -l)

        # if this is the first line of the input file, update the field values
        if [[ $id =~ "id" ]];
        then
                id=$(cat $1 | head -1 | cut -d "," -f 1)
                location_id=$(cat $1 | head -1 | cut -d "," -f 2)
                name_surname=$(cat $1 | head -1 | cut -d "," -f 3)
                title=$(cat $1 | head -1 | cut -d "," -f 4)
                email=$(cat $1 | head -1 | cut -d "," -f 5)
                department=$(cat $1 | head -1 | cut -d "," -f 6)
        fi

        # append the updated field values to the new accounts file
        echo $id","$location_id","$name_surname","$title","$email","$department >> ./accounts_new.csv
done < $1
