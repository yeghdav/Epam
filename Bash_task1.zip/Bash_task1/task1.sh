#!/bin/bash

# create a new file to store the updated accounts
touch ./accounts_new.csv

# read the input file line by line and split the fields using comma as the delimiter
while IFS="," read -r id location_id name title email department;
do
        # check if in the email field is missing @ symbol and email field is not empty
        email_contains_at=$(echo $email | grep "@")
        if [[ -z "$email_contains_at" ]] && [[ -n $email ]];
        then
                # append email value to the end of title field
                title=$title","$email
        fi

        # extract first name from the name field
        first_name=$(echo $name | cut -d " " -f 1)

        # convert first name to lowercase
        first_name_lowercase=${first_name,,}

        # extract last name from the name field
        last_name=$(echo $name | cut -d " " -f 2)

        # convert last name to lowercase
        last_name_lowercase=${last_name,,}

        # combine first and last names with the first letter of each name capitalized
        name_surname="${first_name_lowercase^} ${last_name_lowercase^}"

        # create an email address using the first letter of the first name, last name, location id and the domain "@abc.com"
        email_first_letter=$(echo $first_name_lowercase | cut -c 1)
        email_suffix="@abc.com"
        email="${email_first_letter}${last_name_lowercase}${email_suffix}"

        # if this is the first line of the input file, update the field values
        if [[ $id =~ "id" ]];
        then
                id=$(cat $1 | head -1 | cut -d "," -f 1)
                location_id=$(cat $1 | head -1 | cut -d "," -f 2)
                name_surname=$(cat $1 | head -1 | cut -d "," -f 3)
                title=$(cat $1 | head -1 | cut -d "," -f 4)
                email=$(cat $1 | head -1 | cut -d "," -f 5)
                department=$(cat $1 | head -1 | cut -d "," -f 6)
        fi

        # append the updated field values to the new file
        echo $id","$location_id","$name_surname","$title","$email","$department >> ./accounts_new1.csv
done < $1


while IFS="," read -r id locetion_id name title  email department;
do

        email_dublicates=$(cat ./accounts_new1.csv | grep -iF  "$email" | wc -l)
        # add locetion_id to the email
        if [[ $email_dublicates -eq "1" ]];
        then
                email=$email
        else
                email_1=$(echo $email | cut -d "@" -f 1)
                email_2=$(echo $email | cut -d "@" -f 2)
                email=$(echo $email_1$locetion_id"@"$email_2)
        fi

        echo $id","$locetion_id","$name","$title","$email","$department >> ./accounts_new.csv

done < ./accounts_new1.csv

rm accounts_new1.csv
