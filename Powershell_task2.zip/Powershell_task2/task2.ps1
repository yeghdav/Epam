# Read the CSV file
$accounts = Import-Csv "accounts.csv"

# Define a new array for the modified records
$newAccounts = @()

# Define a hashtable to keep track of duplicate first and last names
$duplicates = @{}

# Loop through each record
foreach ($account in $accounts) {
    # Get the first and last name
    $firstName = $account.Name.Split(' ')[0]
    $lastName = $account.Name.Split(' ')[1]

    # Skip the record if either the first name or last name is null
    if ($firstName -eq $null -or $lastName -eq $null) {
        Write-Warning "Skipping record $($account.id) because it has a null first name or last name"
        continue
    }

    # Check if there are duplicates with the same first and last name
    if ($duplicates.ContainsKey("$firstName $lastName")) {
        # Add the location ID to the email address
        $emailUsername = $firstName.Substring(0,1).ToLower() + $lastName.ToLower() + $account.location_id
        $email = $emailUsername + "@abc.com"

        # Add the email address to the hashtable to ensure uniqueness
        $duplicates["$firstName $lastName"] += 1
    } else {
        # Modify the record
        $account.Name = $firstName.Substring(0,1).ToUpper() + $firstName.Substring(1).ToLower() + " " + $lastName.Substring(0,1).ToUpper() + $lastName.Substring(1).ToLower()
        $emailUsername = $firstName.Substring(0,1).ToLower() + $lastName.ToLower()
        $email = $emailUsername + "@abc.com"

        # Add the email address to the hashtable to ensure uniqueness
        $duplicates.Add("$firstName $lastName", 1)
    }

    # Set the email address
    $account.Email = $email

    # Add the modified record to the new array
    $newAccounts += $account
}

# Export the new array to a CSV file
$newAccounts | Export-Csv "accounts_new.csv" -NoTypeInformation

Write-Host "Finished updating accounts_new.csv"
