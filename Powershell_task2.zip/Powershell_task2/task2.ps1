# Read the CSV file
$accounts = Import-Csv "accounts.csv"

# Define a new array for the modified records
$modAccounts = @()

# Loop through each record
foreach ($account in $accounts) {
    # Get the first and last name
    $firstName = $account.Name.Split(' ')[0]
    $lastName = $account.Name.Split(' ')[1]

    # Add the location ID to the email address
    $emailUsername = $firstName.Substring(0,1).ToLower() + $lastName.ToLower() + $account.location_id
    $email = $emailUsername + "@abc.com"
    # Modify the first and last names
    $account.Name = $firstName.Substring(0,1).ToUpper() + $firstName.Substring(1).ToLower() + " " + $lastName.Substring(0,1).ToUpper() + $lastName.Substring(1).ToLower()

    # Set the email address
    $account.Email = $email

    # Add the modified record to the new array
    $modAccounts += $account
}

# Export the new array to a CSV file
$modAccounts | Export-Csv "accounts_mod.csv" -NoTypeInformation

# Define the input and output file paths
$inputFilePath = "accounts_mod.csv"
$outputFilePath = "accounts_new.csv"

# Read the input CSV file into an array of objects
$accounts = Import-Csv $inputFilePath

# Create a hashtable to store the count of email address prefixes
$emailCounts = @{}
foreach ($account in $accounts) {
    $emailPrefix = $account.email.Split('@')[0] -replace '\d+$'
    if ($emailCounts.ContainsKey($emailPrefix)) {
        $emailCounts[$emailPrefix]++
    } else {
        $emailCounts[$emailPrefix] = 1
    }
}

# Loop through the accounts again and update the email addresses as needed
foreach ($account in $accounts) {
    $emailPrefix = $account.email.Split('@')[0] -replace '\d+$'
    if ($emailCounts[$emailPrefix] -gt 1) {
        # Email prefix has duplicates, so keep the email address unchanged
    } else {
        # Email prefix has no duplicates, so remove digits from the email address
        $account.email = $emailPrefix + "@abc.com"
    }
}

# Export the updated accounts to a new CSV file
$accounts | Export-Csv $outputFilePath -NoTypeInformation

# Remove accounts_mod.csv file
Remove-Item accounts_mod.csv