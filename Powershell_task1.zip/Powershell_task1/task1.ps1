[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidatePattern('^(?:\d{1,3}\.){3}\d{1,3}$')]
    [string]$ip_address_1,

    [Parameter(Mandatory = $true, Position = 1)]
    [ValidatePattern('^(?:\d{1,3}\.){3}\d{1,3}$')]
    [string]$ip_address_2,

    [Parameter(Mandatory = $true, Position = 2)]
    [ValidatePattern('^(255|254|252|248|240|224|192|128|0)\.((255|254|252|248|240|224|192|128|0)\.){0,2}(255|254|252|248|240|224|192|128|0)$|^[1-9]|[1-2][0-9]|3[0-2]$')]
    [string]$network_mask
)

function Get-NetworkAddress {
    param(
        [Parameter(Mandatory = $true)]
        [string]$ip,

        [Parameter(Mandatory = $true)]
        [string]$netmask
    )

    # Convert the IP address and netmask to 32-bit unsigned integers
    $ipInt = [IPAddress]$ip | % { [BitConverter]::ToUInt32($_.GetAddressBytes(), 0) }
    $maskInt = [IPAddress]$netmask | % { [BitConverter]::ToUInt32($_.GetAddressBytes(), 0) }

    # Calculate the network address using bitwise AND operation
    $netInt = $ipInt -band $maskInt

    # Convert the network address back to dotted decimal notation
    [IPAddress]::Parse($netInt.ToString())
}

# Get the network address for the first IP address
$net1 = Get-NetworkAddress $ip_address_1 $network_mask

# Get the network address for the second IP address
$net2 = Get-NetworkAddress $ip_address_2 $network_mask

# Compare the network addresses to see if they belong to the same network
if ($net1 -eq $net2) {
    Write-Output "yes"
}
else {
    Write-Output "no"
}
